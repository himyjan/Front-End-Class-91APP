import styled from "styled-components";
import {} from "./StyledComponents/Thankyou.style";

function Thankyou() {
  return <div className="Thankyou"></div>;
}

export default Thankyou;
