import styled from "styled-components";
import {} from "./StyledComponents/Home.style";

function Home() {
  return <div className="Home"></div>;
}

export default Home;
