import styled from "styled-components";
import {} from "./StyledComponents/Footer.style";

function Footer() {
  return <div className="Footer"></div>;
}

export default Footer;
