import React = require("react");
import styled from "styled-components";
import {} from "./StyledComponents/Header.style";

function Header() {
  return <div className="Header"></div>;
}

export default Header;
