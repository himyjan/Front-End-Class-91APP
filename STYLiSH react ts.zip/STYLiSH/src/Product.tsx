import styled from "styled-components";
import {} from "./StyledComponents/Product.style";

function Product() {
  return <div className="Product"></div>;
}

export default Product;
