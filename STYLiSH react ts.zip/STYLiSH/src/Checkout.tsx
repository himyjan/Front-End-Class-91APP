import styled from "styled-components";
import {} from "./StyledComponents/Checkout.style";

function Checkout() {
  return <div className="Checkout"></div>;
}

export default Checkout;
