import styled from "styled-components";
import {} from "./StyledComponents/Carousel.style";

function Carousel() {
  return <div className="Carousel"></div>;
}

export default Carousel;
